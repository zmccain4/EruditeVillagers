# Steps to 'learn' book0 as a trade 

# Identify books close enough to villagers that don't know book0
execute as @e[tag=bookenchantmentlearnable] at @s if entity @e[tag=book0,distance=0..1.25,limit=1,sort=nearest] run tag @s add booklearnpending

# Add stored enchantments from tagged book to enchanted book trade, and add lore with tradelearn function
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[0].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:0,book:book0,trade:"Novice Level Trade"}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[1].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:1,book:book0,trade:"Novice Level Trade"}

# Make trade tradeable again by resetting the buyB to just a book, with Count:1
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[0].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[0].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[1].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book0,limit=1,sort=nearest] Offers.Recipes[1].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}

# Prevent Villager from learning book0 again
execute as @e[tag=booklearnpending] at @s run tag @e[tag=book0,limit=1,sort=nearest] add book0done
execute as @e[tag=booklearnpending] at @s run tag @e[tag=book0,limit=1,sort=nearest] remove book0

# Visual indicator
execute at @e[tag=booklearnpending] run particle minecraft:poof ~ ~0.5 ~
# Audio Cue
execute at @e[tag=booklearnpending] run playsound item.book.page_turn neutral @a[distance=0..16] ~ ~1 ~ 1 1.0
execute at @e[tag=booklearnpending] run playsound entity.villager.celebrate neutral @a[distance=0..16] ~ ~1 ~ 1 1.1
# Destroy book
execute as @e[tag=booklearnpending] run kill @s


# same for book1
execute as @e[tag=bookenchantmentlearnable] at @s if entity @e[tag=book1,tag=!book0,distance=0..1.25,limit=1] run tag @s add booklearnpending

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[2].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:2,book:book1,trade:"Apprentice Level Trade"}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[3].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:3,book:book1,trade:"Apprentice Level Trade"}

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[2].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[2].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[3].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book1,limit=1,sort=nearest] Offers.Recipes[3].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}

execute as @e[tag=booklearnpending] at @s run tag @e[tag=book1,limit=1,sort=nearest] add book1done
execute as @e[tag=booklearnpending] at @s run tag @e[tag=book1,limit=1,sort=nearest] remove book1

# Visual indicator
execute at @e[tag=booklearnpending] run particle minecraft:poof ~ ~0.5 ~
# Audio Cue
execute at @e[tag=booklearnpending] run playsound item.book.page_turn neutral @a[distance=0..16] ~ ~1 ~ 1 1.0
execute at @e[tag=booklearnpending] run playsound entity.villager.celebrate neutral @a[distance=0..16] ~ ~1 ~ 1 1.1
# Destroy book
execute as @e[tag=booklearnpending] run kill @s

# same for book2
execute as @e[tag=bookenchantmentlearnable] at @s if entity @e[tag=book2,tag=!book0,tag=!book1,distance=0..1.25,limit=1] run tag @s add booklearnpending

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[4].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:4,book:book2,trade:"Journeyman Level Trade"}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[5].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:5,book:book2,trade:"Journeyman Level Trade"}

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[4].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[4].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[5].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book2,limit=1,sort=nearest] Offers.Recipes[5].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}

execute as @e[tag=booklearnpending] at @s run tag @e[tag=book2,limit=1,sort=nearest] add book2done
execute as @e[tag=booklearnpending] at @s run tag @e[tag=book2,limit=1,sort=nearest] remove book2

# Visual indicator
execute at @e[tag=booklearnpending] run particle minecraft:poof ~ ~0.5 ~
# Audio Cue
execute at @e[tag=booklearnpending] run playsound item.book.page_turn neutral @a[distance=0..16] ~ ~1 ~ 1 1.0
execute at @e[tag=booklearnpending] run playsound entity.villager.celebrate neutral @a[distance=0..16] ~ ~1 ~ 1 1.1
# Destroy book
execute as @e[tag=booklearnpending] run kill @s

# same for book3
execute as @e[tag=bookenchantmentlearnable] at @s if entity @e[tag=book3,tag=!book0,tag=!book1,tag=!book2,distance=0..1.25,limit=1] run tag @s add booklearnpending

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[6].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:6,book:book3,trade:"Expert Level Trade"}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[7].buyB{id:"minecraft:enchanted_book"} run function eruditevillagers:tradelearn {slot:7,book:book3,trade:"Expert Level Trade"}

execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[6].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[6].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}
execute as @e[tag=booklearnpending] at @s if data entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[7].buyB{id:"minecraft:enchanted_book"} run data modify entity @e[tag=book3,limit=1,sort=nearest] Offers.Recipes[7].buyB{id:"minecraft:enchanted_book"} set value {id:"minecraft:book",count:1}

execute as @e[tag=booklearnpending] at @s run tag @e[tag=book3,limit=1,sort=nearest] add book3done
execute as @e[tag=booklearnpending] at @s run tag @e[tag=book3,limit=1,sort=nearest] remove book3

# Visual indicator
execute at @e[tag=booklearnpending] run particle minecraft:poof ~ ~0.5 ~
# Audio Cue
execute at @e[tag=booklearnpending] run playsound item.book.page_turn neutral @a[distance=0..16] ~ ~1 ~ 1 1.0
execute at @e[tag=booklearnpending] run playsound entity.villager.celebrate neutral @a[distance=0..16] ~ ~1 ~ 1 1.1
# Destroy book
execute as @e[tag=booklearnpending] run kill @s


# Steps to 'learn' book4 as a trade 

# Identify items close enough to villagers that don't know book4
execute as @e[tag=enchantmentlearnable,tag=!learnt] at @s if entity @e[tag=book4,distance=0..1.25,limit=1] run tag @s add learnpending

# Add enchantment from tagged item to enchanted book trade, and add lore with tooltradelearn function
execute as @e[tag=learnpending] at @s if data entity @e[tag=book4,limit=1,sort=nearest] Offers.Recipes[10].buyB{id:"minecraft:diamond_pickaxe"} run function eruditevillagers:tooltradelearn {slot:10,book:book4,trade:"Master Level Trade"}

# Make trade tradeable again by resetting the buyB to just a book, with Count:1
execute as @e[tag=learnpending] at @s if data entity @e[tag=book4,limit=1,sort=nearest] Offers.Recipes[10].buyB{id:"minecraft:diamond_pickaxe"} run data modify entity @e[tag=book4,limit=1,sort=nearest] Offers.Recipes[10].buyB{id:"minecraft:diamond_pickaxe"} set value {id:"minecraft:book",count:1}

# Prevent Villager from learning book4 again
execute as @e[tag=learnpending] at @s run tag @e[tag=book4,limit=1,sort=nearest] add book4done
execute as @e[tag=learnpending] at @s run tag @e[tag=book4,limit=1,sort=nearest] remove book4

# Visual indicator
execute at @e[tag=learnpending] run particle minecraft:firework ~ ~0.5 ~
# Audio Cue
execute at @e[tag=learnpending] run playsound minecraft:entity.villager.work_weaponsmith neutral @a[distance=0..16] ~ ~1 ~ 1 1.0
execute at @e[tag=learnpending] run playsound entity.villager.celebrate neutral @a[distance=0..16] ~ ~1 ~ 1 0.8

# Uncomment below to remove learned enchantement from item
# execute as @e[tag=learnpending] run data remove entity @s Item.tag.Enchantments[0]

# Uncomment below to destroy item after learning enchantment
# execute as @e[tag=learnpending] run kill @s

# Prevent tool enchantment from being learned by next master villager, until it is picked up and dropped again.
execute as @e[tag=learnpending] run tag @s add learnt
execute as @e[tag=learnpending] run tag @s remove learnpending
