# Remove tags from villagers that have lost job site block:
tag @e[tag=book0,nbt={VillagerData:{profession:"minecraft:none"}}] remove book0
tag @e[tag=book0done,nbt={VillagerData:{profession:"minecraft:none"}}] remove book0done

# Tag trades that have already been modified.
tag @e[type=villager,tag=!book0,tag=!book0done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{sell:{components:{"minecraft:lore":['{"color":"dark_purple","text":"Novice Level Trade"}']}}}]}}] add book0done
tag @e[type=villager,tag=!book1,tag=!book1done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{sell:{components:{"minecraft:lore":['{"color":"dark_purple","text":"Apprentice Level Trade"}']}}}]}}] add book1done
tag @e[type=villager,tag=!book2,tag=!book2done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{sell:{components:{"minecraft:lore":['{"color":"dark_purple","text":"Journeyman Level Trade"}']}}}]}}] add book2done
tag @e[type=villager,tag=!book3,tag=!book3done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{sell:{components:{"minecraft:lore":['{"color":"dark_purple","text":"Expert Level Trade"}']}}}]}}] add book3done

tag @e[type=villager,tag=!book4,tag=!book4done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{sell:{components:{"minecraft:lore":['{"color":"dark_purple","text":"Master Level Trade"}']}}}]}}] add book4done

# Tag trades that are pending modification. (Excluding already modified trades tagged with book#done)
tag @e[type=villager,tag=!book0,tag=!book0done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:custom_name":"Learn Novice Level Trade"}}}]}}] add book0
tag @e[type=villager,tag=!book1,tag=!book1done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:custom_name":"Learn Apprentice Level Trade"}}}]}}] add book1
tag @e[type=villager,tag=!book2,tag=!book2done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:custom_name":"Learn Journeyman Level Trade"}}}]}}] add book2
tag @e[type=villager,tag=!book3,tag=!book3done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:custom_name":"Learn Expert Level Trade"}}}]}}] add book3

# Format: /tag @e[type=villager,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:enchantment_glint_override":true}}}]}}] add Test
tag @e[type=villager,tag=!book4,tag=!book4done,nbt={VillagerData:{profession:"minecraft:librarian"}},nbt={Offers:{Recipes:[{buyB:{components:{"minecraft:enchantment_glint_override":true}}}]}}] add book4

# Tag books and items that could be used to modify trades.
tag @e[tag=!bookenchantmentlearnable,type=item,nbt={Item:{id:"minecraft:enchanted_book"}}] add bookenchantmentlearnable
tag @e[tag=!enchantmentlearnable,type=item,nbt={Item:{components:{"minecraft:enchantments":{}}}}] add enchantmentlearnable
